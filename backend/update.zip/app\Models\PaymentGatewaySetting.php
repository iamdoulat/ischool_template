<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentGatewaySetting extends Model
{
    protected $fillable = [
        'provider',
        'config',
        'status',
    ];

    protected $casts = [
        'config' => 'array',
        'status' => 'boolean',
    ];
}
